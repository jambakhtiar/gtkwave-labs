#include <iostream>
#include <cstdlib>

int main(int argc, char *argv[]) {
    std::cout << "Hello, World!" << std::endl;
    return EXIT_SUCCESS;
}